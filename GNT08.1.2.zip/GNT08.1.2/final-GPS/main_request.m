Hello;

The GNT08.2.1 can be accessed by sending a request email to moeinmehrtash@yahoo.com.

Thanks,
Moein