ACFR Thesis Template
--------------------

LaTeX template for ACFR PhD or MPhil thesis.

The intent of this template is to provide a uniform starting point for thesis
layout in LaTeX, together with helpful examples of solutions to common needs.

This template was developed over many years, originally from a version brought
from Oxford, probably by Paul Newman. Many people have contributed to it over
the years, but thanks are due particularly to Andrew Hill, Tom Allen and Dave
Wood for getting it in 2011 in a form suitable for distribution.
    
If you have suggestions for improvements, please contact David Rye. 


